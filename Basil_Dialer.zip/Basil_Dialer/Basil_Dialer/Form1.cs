﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Joe Basil
//IT112
//Notes: I feel like my most creative portion of the project was splitting the contact into multiple arrays because I was struggling with figuring out how to get each piece of information within a single string
// Behaviors not implimented and why: I didn't include the sublasses as both I could not figure out how and once I found a workaround found it obsolete for the project to function as my workaround with the arrays allows me to take any given part of the contact info at a single time and us a simple if/ else if statement
namespace Basil_Dialer
{
    public partial class Form1 : Form
        
    {
        public Form1()
        {
            InitializeComponent();      
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void cboContacts_SelectedIndexChanged(object sender, EventArgs e)
        {
                                                       
        }

        private void btnDial_Click(object sender, EventArgs e)
        {
            int x = cboContacts.SelectedIndex;
            string jon = "";
            var Chrima = new string[10];
            Chrima[0] = "Computest";
            Chrima[1] = "Curtis Manufacturing";
            Chrima[2] = "Data Functions";
            Chrima[3] = "Donnay Repair";
            Chrima[4] = "ErgoNomic Inc";
            Chrima[5] = "ErgoSource";
            Chrima[6] = "Fox Bay Industries";
            Chrima[7] = "Glare-Guard";
            Chrima[8] = "Hazard Comm Specialists";
            Chrima[9] = "Komfort Support";
            var Turkey = new string[10];
            Turkey[0] = "(303) 985-5060";
            Turkey[1] = "(603) 532-4123";
            Turkey[2] = "(800) 876-2524";
            Turkey[3] = "(708) 397-3330";
            Turkey[4] = "(360) 434-3894";
            Turkey[5] = "(800) 969-4374";
            Turkey[6] = "(800) 874-8527";
            Turkey[7] = "(800) 545-6254";
            Turkey[8] = "(407) 783-6641";
            Turkey[9] = "(714) 472-4409";
            var cat = new int[10];
            cat[0] = 1;
            cat[1] = 2;
            cat[2] = 1;
            cat[3] = 1;
            cat[4] = 1;
            cat[5] = 1;
            cat[6] = 2;
            cat[7] = 2;
            cat[8] = 2;
            cat[9] = 2;
            var wevi = Chrima[x];
            int Tomm = cat[x];
            var john = Turkey[x];
            string Tom = john.ToString();
            if (Tomm == 1)
                jon = "";
            else if (Tomm == 2)
                jon = "1+";
            txtDialOutput.Text = "You are now dialing " + wevi + " using " + jon + Tom;;
        }

        private void txtDialOutput_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

