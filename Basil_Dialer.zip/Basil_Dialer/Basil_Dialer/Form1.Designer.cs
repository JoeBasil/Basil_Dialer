﻿namespace Basil_Dialer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboContacts = new System.Windows.Forms.ComboBox();
            this.btnDial = new System.Windows.Forms.Button();
            this.lblContacts = new System.Windows.Forms.Label();
            this.txtDialOutput = new System.Windows.Forms.TextBox();
            this.lblDialOutput = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cboContacts
            // 
            this.cboContacts.FormattingEnabled = true;
            this.cboContacts.Items.AddRange(new object[] {
            "CompuTest",
            "Curtis Manufacturing",
            "Data Functions",
            "Donnay Repair",
            "ErgoNomic Inc",
            "ErgoSource",
            "Fox Bay Industries",
            "Glare-Guard",
            "Hazard Comm Specialists",
            "Komfort Support"});
            this.cboContacts.Location = new System.Drawing.Point(12, 38);
            this.cboContacts.Name = "cboContacts";
            this.cboContacts.Size = new System.Drawing.Size(121, 21);
            this.cboContacts.TabIndex = 0;
            this.cboContacts.SelectedIndexChanged += new System.EventHandler(this.cboContacts_SelectedIndexChanged);
            // 
            // btnDial
            // 
            this.btnDial.Location = new System.Drawing.Point(139, 38);
            this.btnDial.Name = "btnDial";
            this.btnDial.Size = new System.Drawing.Size(41, 23);
            this.btnDial.TabIndex = 2;
            this.btnDial.Text = "Dial";
            this.btnDial.UseVisualStyleBackColor = true;
            this.btnDial.Click += new System.EventHandler(this.btnDial_Click);
            // 
            // lblContacts
            // 
            this.lblContacts.AutoSize = true;
            this.lblContacts.Location = new System.Drawing.Point(47, 22);
            this.lblContacts.Name = "lblContacts";
            this.lblContacts.Size = new System.Drawing.Size(49, 13);
            this.lblContacts.TabIndex = 3;
            this.lblContacts.Text = "Contacts";
            // 
            // txtDialOutput
            // 
            this.txtDialOutput.Location = new System.Drawing.Point(186, 41);
            this.txtDialOutput.Name = "txtDialOutput";
            this.txtDialOutput.ReadOnly = true;
            this.txtDialOutput.Size = new System.Drawing.Size(374, 20);
            this.txtDialOutput.TabIndex = 4;
            this.txtDialOutput.TextChanged += new System.EventHandler(this.txtDialOutput_TextChanged);
            // 
            // lblDialOutput
            // 
            this.lblDialOutput.AutoSize = true;
            this.lblDialOutput.Location = new System.Drawing.Point(198, 22);
            this.lblDialOutput.Name = "lblDialOutput";
            this.lblDialOutput.Size = new System.Drawing.Size(35, 13);
            this.lblDialOutput.TabIndex = 5;
            this.lblDialOutput.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(583, 75);
            this.Controls.Add(this.lblDialOutput);
            this.Controls.Add(this.txtDialOutput);
            this.Controls.Add(this.lblContacts);
            this.Controls.Add(this.btnDial);
            this.Controls.Add(this.cboContacts);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboContacts;
        private System.Windows.Forms.Button btnDial;
        private System.Windows.Forms.Label lblContacts;
        private System.Windows.Forms.TextBox txtDialOutput;
        private System.Windows.Forms.Label lblDialOutput;
    }
}

